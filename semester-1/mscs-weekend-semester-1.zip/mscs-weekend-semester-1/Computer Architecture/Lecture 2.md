**28 September, 2025**
#### **Computer Components**
- CPU
- Main Memory
- I/O Module
Interconnected via System
- **Notations**
	- Program Counter: PC - PC holds the pointer to the next instruction
	- Instruction register: IR
	- Memory address register: MAR
	- Memory Buffer Register: MBR
	- I/O AR = I/O Address Register
	- I/O BR = I/O Buffer Register
- Instructions are stored in the main memory.
#### **Instruction Cycle**
- Execution of a program which consists of a set of instructions stored in memory.
1. **Fetch Instruction** (Fetch Cycle) - Shorter duration
		Fetch instruction from RAM and load into IR
2. **Execute Instruction** (Execution Cycle) - Longer duration
	1. Could be **processor-memory** data transfer between CPU and main memory
	2. Could be **processor I/O** data transfer between CPU and I/O module
	3. Could be **data processing** - Some arithmetic or logical operation on data
	4. Could be **program control** - like `if-else`
#### **Instruction Format**
- A single instruction consists of opcode + address (to the data being operated).
#### **Basic Cycle**
1. Obtain instruction and store it into IR
2. Decode instruction - what is the opcode and what data is needed
3. Fetch the data of the operands from the RAM (mostly, the operands are loaded in the accumulator AC).
4. Execute the instruction.
5. Store the computed data back into the memory (optional).
6. Fetch the next instruction and move the PC over there.
#### **Interrupts**
Mechanism by which other modules (e.g I/O) may interrupt normal sequence of processingg.
- Provides processor efficiency as it will not make processor idle frequently.
- Caused by **programs** when any issue happens (arithmetic overflow, out of bound), **timer based** (regularly addressing different tasks - preemptive multi-tasking), **I/O signal**, hardware failure.
#### **Computer Modules**
- **Bus**
	- Data Bus
	- Address Bus
	- Control Bus
- **Single Bus Problems**
	- Expansion bus interface contains a buffer to mediate the pace of speed from the I/O devices.
	- Problems:
		- Long data paths and single pathway leads to congestion.
		- Multiple devices with different speeds can lead to a inefficient processor.
- **High Performance Bus Architecture**
	- With expansion bus, there is a new high-speed bus. There is a cache/ bridge connected to the system bus (intermediary to processor). Faster devices are connected high-speed one. A local bus connects processor to a cache controller, which in turn connected to a system bus that supports memory.
#### **Elements of a bus design**
- Type: Dedicated (division of lines dedicated for each separate line) / Multiplexed (single line with sequential treatment of addresses)
- Bus Width: Bigger address and data size leads to faster bus.
- Data Transfer Type: Read, Write
- **Bus Arbitration:** More than one module may need to control the bus (like an I/O module may need to read/write data directly to memory without sending data to processor).
	- **Centralized:** A single hardware device is responsible for allocation time on the bus. (bus controller & arbiter)
	- **Distributed:** No central controller. Each module can access the bus.