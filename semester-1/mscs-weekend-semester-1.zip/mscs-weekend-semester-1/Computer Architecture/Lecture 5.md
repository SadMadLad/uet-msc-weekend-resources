**October 19, 2025**
Hypothetical situation
- 16MB RAM
- Cache ($2^{14}$)of 64kByte.
- Each line in block/line of cache is 4 bytes
	- There are 16k lines of caches with 4 bytes. Hence total size: 16k \* 4.
- Hence, number of blocks/lines of main memory: 16M / 4 = 4M lines.
### **Direct Mapping**
- Division of main memory into segments.
- Here, in our situation, there are 4M / 16k segments = 250 Segments of main memory that can be directly mapped to cache.
- In our main memory, there are 250 segments, with each one segments having labelled from 0 to 249 lines.
- Each labelled line (like line 0 of segment 0) will occupy that specific line label of cache (line 0). Other segments once cached will override that specific label (like line 0 of segment 1 if segment is to be cached).
- To completely fetch our specific word from memory, we would need **24-bit address**
	- First 22 bits will identify the block/line.
	- The last 2 bits will identify the word.
	- For example, if we have 1111111111111111111100, this will map to last line of the main memory - denoted by s - (the first 22 bits indicate the last block), and the first word - denoted by w - (the last two bits 00 indicate the first word).
- In our hypothetical example:
	- Address length: s + w bits. s = 22, w = 2. 22 + 2 = 24
	- Number of addressable units = $2^{s+w}$ = $2^{24}$
	- Block size = Line Size = $2^w$ = $2^2$.
	- Number of blocks in main memory = $2^s$
	- Number of lines in cache = m = $2^{14}$ lines.
	- Size of tag = (s - r) = 22 - 14 = 8 bits
	- When looking into the cache, the processor will look for tag (s-r), then the line or slot.
- Division into 3 parts when processor is asking for a value:
	- 8-bit tag + 14-bit cache line + 2-bit word.
	- If processor is asking for 16FFFC. 16-> Denote the tag. FFF and the first two bits of C denote the line number (it is calculated as 3FFF). And the last two bits - 00, denote the word number.
- Very simple, inexpensive, but the if the processes accesses two blocks that map to the same line repeatedly, cache misses are very high.
