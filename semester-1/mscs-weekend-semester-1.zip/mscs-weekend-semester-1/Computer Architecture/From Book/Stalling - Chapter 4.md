#### Example 1: **Byte-addressable memory**
- Each address points to **1 byte**.
- Let’s say the CPU uses **A = 16-bit addresses**.
- That means it can make **2¹⁶ = 65,536 addresses**.
- So it can address **65,536 bytes** = **64 KB of memory**.
#### Example 2: **Word-addressable memory**
- Each address points to **1 word**, and 1 word = **4 bytes**.
- If A = 16 bits again → 2¹⁶ = 65,536 words.
- But since each word = 4 bytes → total memory = 65,536 × 4 = **262,144 bytes (256 KB)**.
### **Principle of Locality**
> **Programs tend to use the same small set of data and instructions again and again, for short periods of time.**
#### **Temporal Locality** (Time-based)
> “If you used something recently, you’ll probably use it again soon.”
#### **Spatial Locality** (Space-based)
> “If you use something in memory, you’ll probably use nearby items soon.”
