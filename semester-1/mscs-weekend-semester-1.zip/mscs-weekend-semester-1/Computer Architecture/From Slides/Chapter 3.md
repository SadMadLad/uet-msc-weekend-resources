Multiple Interrupts
- Disable them and processor will check them later.
- Define priorities
Ways to handle:
- Sequential
- Nested
Async vs Sync timing
- Sync is easier to implement but less flexible.
- Sync:
	- Single cycle for event.
	- Usage of clock
	- Because of clock, system needs to work with even the faster I/O. (so no benefit of faster I/O)
- Async:
	- Depends on the acknowledgement of previous events.
	- Complex to implement
	- Can benefit from faster I/O, however, there will be a hodgepodge of slower and faster devices.
- PCI
	- Stands for Peripheral Interconnection Bus.
	- Uses synchronous timing and centralized arbitration.
	- 64 lines bus with 66MHz data transfer for 528MBytes/second.
	- Centralized Arbitration and Synchronous Timing.