**5 October, 2025**
**Timing**
- A way in which events are coordinated on bus.
- **Synchronous timing**
	- Occurrence of events on bus is determined by clock.
	- Events are 'pre-decided'.
	- Fixed amount of data will be shared in fixed amount of time.
	- No need of acknowledgement (i.e. informing if the data has been received and whatnot).
- **Asynchronous timing**
	- Occurrence of one event on bus follows and depends on occurrence of a previous event.
### Chapter 4 - Cache Memory
