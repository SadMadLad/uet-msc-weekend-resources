**Date: 21 December, 2025**
### **Immediate Addressing**
- Operand value is in the instruction
- Used for setting constants or initial values of variables.
- Advantage: No concept of memory. Fast.
- Disadvantage: Limited usage. Limited to how many bits can be specified for constant.
### **Direct Addressing**
- Operand field contains the address to the variable.
- Effective Address = Operand Address - EA = A.
	- (A) indicates 'contents of A'.
- Advantage: More usage of memory
- Disadvantage: Limited memory space (for 32 bit machine, if 28 bits are for operand, we only could access 64MB of RAM)
### **Indirect Addressing**
- With direct addressing, the length of the address field is usually less than the word length, thus limiting the address range. One solution is to have the address field refer to the address of a word in memory, which in turn contains a ­full-​­length address of the operand. This is known as indirect addressing
	- EA = (A)
- Advantage: Flexible. All access.
- Disadvantage: Complex. Instruction requires two memory references to fetch the operand: one to get the operand and a second to get the value.
	- EA = (..(A)..) - Multilevel cascading style indirect access.
### **Register Addressing**
- Similar to direct addressing, difference being the operand contains register address R instead of entire operand address A
	- EA = R
- Advantage: Faster, No time consuming
- Disadvantage: Limited address space
- If we have a 32-bit machine with opcode of 4 bits, the entire 28 bits are free for register addressing. 2<sup>28</sup> possible register spaces. However, typically there are like 2<sup>8</sup> registers so entire operand spacing for specifying register is wasted.
### **Indirect Register Addressing**
- Register has address to RAM.
	- EA = (R)
- Advantage: More space available. Fewer memory access than indirect addressing.
### **Displacement Addressing**
- EA = A + (R)
### **Relative Addressing**
- EA = A + (PC)
