**October 12, 2025**
# Chapter 4 - Cache Memory
**Inboard Memory** - within motherboard
- Registers
- Cache
- Main Memory
**Outboard Memory**
- Magnetic Disk
- CD-ROM
**Offline Storage**
- Magnetic tapes
More memory -> Less performant
### **Characteristics**
- Location (internal / external)
- Capacity (number of bytes)
- Unit of Transfer (Word, Block)
- Access Method (Sequential, Direct, Random, Associative)
- Performance
#### **Performance**
- Access Time - Time between presenting the address and getting the valid data for RAM time to perform read/write op.
- Memory Cycle Time - Time may be required for the memory to recover before next access.
- Transfer Rate
#### **Access Methods**
- **Sequential**: Start at the beginning and read through in order. e.g. tape.
- **Direct**: Individual blocks having unique address. e.g. disk.
	- Magnetic tracks, circular. Access time depends on finding the right cluster and then the right block, some sequential search is involved.
- **Random**: Individual address identify locations exactly. Access time is independent of previous location.
	- e.g. RAM. Blocks are made.
- **Associative**: Data is located by a comparison with contents of a portion of the store. Similar time is independent of location or previous access. e.g. cache.
#### **Trade-offs**
- Faster access time, greater cost per bit.
- Greater capacity, smaller cost per bit.
- Greater capacity, slower access time.
To maximize it, we need to employ memory hierarchy.
### **Cache Memory**
- Small amount of memory, sits between normal main memory and CPU.
- Communication between CPU and Cache - word transfer (faster). Communication between Cache and Main memory - block transfer (slower).
- Retention for faster access.
- L2 cache is slower and larger than the L1 cache and so on.
- **Cache Operation**
	- CPU asks for memory address.
	- The asked data is retained in memory.
	- If the data exists in cache, it is a **cache hit**. If its not a hit, new data is retained on the cache.
	- **Structure**
		- Main memory consists of $2^n$ addressable words.
		- Each word having a unique n-bit address, memory consists of a number of fixed-length blocks of K words - $M = 2^n / K$ blocks.
		- Cache consists of C lines of K words each and C << M
		- Tag is usually a portion of main memory address.
		- The block in cache is called a cache line.
		- Each line and block has same count of words in their respective compartment (RAM and Cache)
		- The data transfer between CPU and cache is block by block (not really word by word)
	- **Cache Organization**
		- Address buffer is unidirectional.
		- Data buffer is fully duplex.
### **Mapping Function**
Fewer cache lines than main memory blocks, hence an algorithm is need for mapping main memory blocks into cache lines.
1. **Direct Mapping**
	- Simplest technique.
	- Each block can only be placed in certain cache line.