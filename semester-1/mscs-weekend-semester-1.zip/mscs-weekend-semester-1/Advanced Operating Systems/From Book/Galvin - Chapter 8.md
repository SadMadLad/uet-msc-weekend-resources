**Requirements for a deadlock and prevention**
- **Mutual Exclusion:** A resource must be non-shareable — only one process/thread can use it at a time.
	- A mutex lock is a non-shareable resource, while read-only files are shareable resources.
	- Preventing this is hard because major processes have non-shareable resources.
- **Hold and Wait:** A process/thread is holding at least one resource and waiting for additional resources.
	- Can be prevented if a thread requests a resource, it itself does not have any resources.
	- This can be done but leads to two major disadvantages:
		- Resources utilization is low - some processes might need a resource for a short duration but they would have to wait for a long time.
		- Leads to starvation - if a processor needs 10 resources, it would need all 10 of them available at the same time as it cannot lock, hold and wait the resources one by one. Each resource might be being used by some other process and that process would never get what it wants simultaneously.
- **No Preemption:** Resources cannot be forcibly taken away from a thread; the thread must release them voluntarily.
	- Can be achieved by implicit releasing of resources that are being held by threads. However, not applicable as most of the resources are not saved and restored easily, like mutex locks and semaphores - where deadlocks happen commonly.
- **Circular Wait:** If we have threads T0, T1, ... Tn, such that T0 is waiting for a resource allocated to T1, T1 is waiting for a resource allocated to T2...Tn-1 is waiting for resource allocated to Tn and Tn is waiting for a resource allocated to T0.
	- Probably the most viable way to prevent deadlock among other conditions. How you do it? You label the resources numerically, and then a thread cannot request a resource with a _smaller_ ordering number than any resource it currently holds. For example, if I have resources A and B, numbered 1 and 2. Thread T1 has a lock on A but wants a lock on B, it can do it (because F(A) < F(B)). Thread T2 has a lock on B but wants a lock on A, it cannot do it (because (FB) > F(A)). To get the resource A, T2 must release the lock on B, breaking the cycle. 
**Deadlock Prevention vs Deadlock Avoidance**
- **Prevention:** Preventing at least one of the four requirements for the deadlock.
- **Avoidance:** Knowing the allocation of resources and processes ahead of time, we can decide how we can avoid deadlock.
**Deadlock Avoidance**
	One piece of information that can help us avoid deadlocks is by knowing the maximum number of resources available and the requirements of threads.
- **Safe State**
	- With some resources available, there exists a safe state if there is a sequence where all the threads can be executed in that particular order, freeing up the resources eventually so that all other threads can be executed safely.
		- If safe state is not guaranteed, we are in unsafe territory.
			- Unsafe state does not mean deadlock. It only means that *deadlock may happen*.
- **Resource-Allocation-Graph (RAG) Algorithm**
	- There are claim edges represented with dashed lines, indicating if a thread may need a resource.
	- We need to find cycles in RAG to see if the system is in unsafe state or not and deadlocks may happen. Conversions (during these conversions, at every instance, check for loops in the graph):
		1. When thread T needs a resource R, convert the claim edge into a request edge T->R.
		2. When R is granted it to T, convert it into an assignment edge R->T.
		3. When T is done with R, convert it back to claim edge T-->R.
- **Banker's Algorithm**
	- A deadlock avoidance algorithm
	- Can also be used for deadlock detection