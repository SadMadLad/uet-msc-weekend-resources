**Date: 01 November, 2025**
- **Deadlock Characterization**
	- **Mutual exclusion:** Only one thread at a time can use a resource.
	- **Hold and Wait**
	- **No preemption:** After task completion, the next one will pickup the thread.
	- **CIrcular Wait**
- **Resource Allocation Graph**. Threads and Resources. Request edge: T<sub>i</sub> -> R<sub>i</sub>. Assignment edge: R<sub>i</sub> -> T<sub>i</sub>
- If there is a cycle in Resource Allocation Graph, if there is a cycle, there is a chance that deadlock will happen there. 