# Reduced Instruction Set Computers
- Progress Made
	- The family concept
	- Microprogrammed Control Unit (MCU)
	- Cache Memory
	- Solid State RAM
	- Pipelining
	- Multiple Processors
- RISCs take a different philosophy
	- Lots of general purpose registers. Optimization left to compiler.
	- Limited instruction set.
	- Focus on improving instruction pipeline.
# Instruction Pipelining
- Time to complete N instructions = (Pipeline depth + N - 1) × Clock cycle time
- Divided into 6 sets:
	- FI: Fetch Instruction
	- DI: Decode Instruction
	- CO: Calculate Operand
	- FO: Fetch Operand
	- EI: Execute Instruction
	- WO: Write Operand
# Instruction Sets: Addressing Modes and Formats
- **Immediate Addressing:** Operand = Address Field
- **Direct Addressing:** EA = A
- **Indirect Addressing:** EA = (A)
- **Register Addressing:** EA = R
- **Indirect Register Addressing:** EA = (R)
- **Displacement Addressing:** EA = A + (R)
- **Relative Addressing:** EA = A + (PC)
- **Base-Register Addressing:** EA = A + R
- **Indexed Addressing**: Similar to Base-Register Addressing
- **Stack Addressing:** Top of the stack
- **Postindex Addressing:** EA = (A) + (R)
- **Preindex Addressing:** EA = (A + (R))
- How many times does the processor need to refer to memory when it fetches and executes an indirect-​­address-​­mode instruction if the instruction is (a) a computation requiring a single operand; (b) a branch?
	- 3 times: Fetch Instruction, Fetch Operand Reference, Fetch Operand
	- 2 times: Fetch Instruction, Fetch Instruction and Store Operand in PC for branch
- How to take a 2's complement?
	- Invert bits and add 1
	- 5 in 4-bits: 0101
	- -5 in 4-bits: 1011
- Convention for **SUB**: Usually `SUB` does `second-top - top` (i.e., `POP b, POP a, compute a - b, push result`).
- Justify the assertion that a 32-bit instruction is probably much less than twice as useful as a 16-bit instruction.
	- A 16-bit instruction already encapsulates all the opcodes and sufficient data. As a result, the return is diminishing in nature as most of the bits are wasted. It does allow for bigger constants value but that's pretty much it.
- Why was IBM’s decision to move from 36 bits to 32 bits per word wrenching, and to whom?
	- The earlier programs written in 36 bit systems would then not work on newer 32 bit systems which was devastating for old IBM users and bad for IBM.
- Is there any possible justification for an instruction with two opcodes?
	- No. If the two opcodes conflict, the instruction is meaningless. If one opcode modifies the other or adds additional information, this can be viewed as a single opcode with a bit length equal to that of the two opcode fields. However, instruction bundles, such as seen on the IA-64 Itanium architecture, have multiple opcodes.
- Exercise Questions: 13.1, 13.2, 13.3, 13.4, 13.5, 13.6, 13.7, 13.8, 13.11, 13.13-17, 13.19, 13.20
# Instruction Sets: Characteristics and Functions
![[three-two-one-address.png]]
![[big-little-endian.png]]
Exercise Questions: 12.6
# Internal Memory & Chip Logic
- RAS: Row Access Control, CAS: Column Access Control, WE: Write Enable, OE: Output Enable
- Hamming Code
	- 2<sup>k</sup> - 1 >= M + k where M is the count of bits and k is the count of parity bits.
- Chip Packaging
	- Vss: Ground Pin
	- Vpp: Pin for write operations
	- Vcc: Power supply to chip
- Exercise Qs: 5.2, 5.3, 5.6, 5.8, 5.10-14
# Cache Memory
![[pentium.png]]![[set.png]]