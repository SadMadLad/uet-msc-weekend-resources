**Date: October 25, 2025**
- **Reflexive Relation**
	- A relation is said to be reflexive if it is related to itself.
		- $f(n) = O(f(n))$
		- $n^2 = O(n^2)$
		- Big-O, Big-Omega, Big-Theta hold the reflexive property, but does not always hold for Small-O, Small-Omega (because of hard bounds)
- **Symmetric Relation**
	- A relation is said to be symmetric if $f(n) \le c.g(n)$ and $c.g(n) \le f(n)$
	- This does not hold true for Big-Omega or Big-O.
- **Transitive Relation**
	- A relation is transitive if $f(n) \le g(n)$ and $g(n) \le h(n)$, then $f(n) \le h(n)$
	- This holds true for Big-Omega, Big-Theta, Big-O.
### **Recursion**
- Using the substitution method: Keep on substituting the equating till you notice the trend.