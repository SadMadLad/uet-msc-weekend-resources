**October 18, 2025**
- Practiced problems