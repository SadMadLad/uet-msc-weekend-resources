**4 October, 2025**
$\exists c > 0, \exists n_0 >= 0$ and $\forall n >= n_0, 0 <= f(n) <= c.g(n)$
$g(n)$ is an asymptotic upper bound for $f(n)$.
- Practiced some questions.