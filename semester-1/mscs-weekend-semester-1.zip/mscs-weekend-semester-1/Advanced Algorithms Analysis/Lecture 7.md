**Date: 01 November, 2025**
- More practice of substitution method.