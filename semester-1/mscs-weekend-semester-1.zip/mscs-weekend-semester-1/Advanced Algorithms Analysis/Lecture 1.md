**20 September, 2025**
- Algorithm Optimization - Optimized according to the scope of the problem.
- Book mentioned (presumably) - Introduction to Design and Analysis of Algorithms
- Criteria - Space and Time