**Date: 28 December, 2025**
- a<sup>n</sup>b<sup>n</sup>
	- ![[pushdown_anbn]]
- Odd Palindrome
	- ![[odd_palindrome_pda]]