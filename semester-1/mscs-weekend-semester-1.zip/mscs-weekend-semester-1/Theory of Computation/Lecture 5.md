**October 19, 2025**
### **Transition Graph**
- Difference between Finite Automata (FA) vs Transition Graph (TG)
	- FA had restrictions.
		- Every state must have transitions equal to the language characters.
		- We can read letters but not strings.
		- It is DFA (Deterministic Finite Automata).
		- No null string transition.
	- TG has lifted up most of the restrictions above
		- We can move from one state to other by reading strings.
		- Multiple outgoing transitions for a single character are possible.
		- Outgoing null transition is also possible.
		- It is NFA (Non-deterministic Finite Automata)
- Transition Graph Definition
	1. Finite number of state **at least one** of which is designated as start state. There may be many (maybe none) final state.
	2. An alphabet Σ of possible input characters Σ = {a, b}
	3. A transition that tells how to proceed from one state to another by reading some input character or string.
- Every FA is a TG, but not every TG is FA.
![[tg_accepts_baa]]
![[tg_accepts_nothing]]
![[tg_accepts_double_letters]]
![[tg_ending_different_characters]]
![[tg_even_even]]