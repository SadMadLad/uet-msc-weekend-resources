**October 12, 2025**
- Find minimum word of the language.
- Dead-end / Non-final state: Which does not accept anything further.
- Deterministic finite automatic.
- Final state - multiple with different letters.
### **Finite Automata Practice**
![[fa_dont_end_with_b]]
![[fa_dont_end_with_ba]]
![[fa_double_letters]]
![[fa_even_automata]]
![[fa_starting_and_ending_with_a]]
![[fa_starting_with_a]]
![[fa_starting_with_different_letters]]
