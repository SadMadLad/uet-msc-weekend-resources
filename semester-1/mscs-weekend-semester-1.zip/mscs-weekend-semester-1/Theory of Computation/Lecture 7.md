**Date: 02 November, 2025**
Transition table of RE's FA 1: All words having double a (aa)

| State | a   | b   |
| ----- | --- | --- |
| - X1  | X2  | X1  |
| X2    | X3  | X1  |
| +X3   | X3  | X3  |
Transition table of RE's FA 2: Even Even

|       | a   | b   |
| ----- | --- | --- |
| -+ Y1 | Y2  | Y3  |
| Y2    | Y1  | Y4  |
| Y3    | Y4  | Y1  |
| Y4    | Y3  | Y2  |
Union of FA 1 and FA 2.
Transition Table of Union

|       |     |     |
| ----- | --- | --- |
| -+ Z1 | Z2  | Z3  |
| Z2    | Z4  | Z5  |
| Z3    | Z6  | Z1  |
| +Z4   | Z7  | Z8  |
| Z5    | Z9  | Z10 |
| Z6    | Z8  | Z10 |
| +Z7   | Z4  | Z11 |
| +Z8   | Z11 | Z4  |
| Z9    | Z11 | Z1  |
| Z10   | Z12 | Z5  |
| +Z11  | Z8  | Z7  |
| +Z12  | Z7  | Z3  |
![[tg_proof_re_fa]]
