**28 September, 2025**
#### **Regular Expressions**
- 'A formula / mathematical notation to showcase the entire set of language'.
- Regular expressions help us to define patterns, rules, sequences that can define any generic set of language.
1. Every letter of Σ can be made into regular expression by writing it into bold face. Λ itself is regular. (Σ contains all the characters of the language)
2. If r<sub>1</sub> and r<sub>2</sub> are two regular expressions, then
	1. r<sub>1</sub> + r<sub>2</sub> is regular. (+ is the union operator, can be called as OR too)
	2. r<sub>1</sub> .  r<sub>2</sub> is regular
	3. r<sub>1</sub><sup>*</sup>, r<sub>2</sub><sup>*</sup> are regular.
3. Nothing else is regular.
- $x.x^* = x^*.x = x^+$
- $a.b^* = {a, ab, abb, abbb, abbbb, ...}$
- $a + b =$ Either a or b.
- $(a+b)^2=$ aa + ab + ba + bb = All possible combinations of a and b of length 2.
- $(a + b)^*$ = Λ, a, b, aa, ab, ba, bb, ... = All possible of combinations of a and b (of any length).
**Q.** Write down a regular expression for all words starting with a and Σ = { a, b }
**A.** a(a + b)<sup>*</sup>
**Q.** Write down a regular expression for all words ending with a and Σ = { a, b }
**A.** (a + b)<sup>*</sup>.a
**Q.** S = {a, c,  ab, cb, abb, cbb, ...}
**A.** (a + c)b<sup>*</sup>
**Q.** All words having at least one 'a'. Σ = {a, b}
**A.** (a + b)<sup>*</sup>.a.(a + b)<sup>*</sup>
**Q.** All words having at least one a and one b. Σ = {a, b}
**A**. (a + b)<sup>*</sup>a(a+b)<sup>*</sup>b(a+b)<sup>*</sup> + (a+b)<sup>*</sup>b(a+b)<sup>*</sup>a(a+b)<sup>*</sup>
**Q.** All words having double a. Σ = {a, b}
**A.** (a + b)<sup>*</sup>aa(a + b)<sup>*</sup>
**Q.** All words having double letter. Σ = {a, b}
-
