**21 September, 2025**
- **Compiler**
	- Uses mathematical models - Abstract ones.
	- Generates machine code.
	- Parts
		- Syntax analyzer
		- Semantic analyzer
		- Lexical analyzer
- **Basics of English**
	- Characters - Fundamental blocks
	- Words / Strings - Combination of characters
	- Sentence - Combination of words
	*We need to check for validity of strings and sentences*

- **Language**
	- A certain specified set of strings of characters from alphabets (a valid 'set' of characters).

- Some rules
	- a<sup>0</sup> = Λ (Null String). Similar to phi (empty) set in mathematics.
	- a.Λ = a
	- Λ.Λ = Λ
	- No multiplication. Instead concatenation (addition of strings in code). Not commutative. Order matters (unlike numerical multiplication)
- **Operators**
	- Kleene Star (`*`) - Makes an infinite language
		- If I have a set like `L = [a, b]`, then `L*` would be any combination of all the characters of `L`. `L* = [Λ, a, b, aa, bb, aab, aaa, ...]`. Basically all combination of letters. (The Λ is a combination of a<sup>0</sub>.b<sup>0</sup>)
		- Lexicographic order:  Lengthwise combination in alphabetic order. The lexicographic combination of the set `L` will look like `[Λ, a, b, aa, ab, ba, bb, aaa, aab, aba, abb, baa, bab, ...]`.
		- If we have `L = [a, b]` and `M = [b, a]`, `L* = M*`.
	- Plus (`+`) - Makes an infinite language without Λ.
		- If I have a set like `L = [a, b]`, then `L+` is same as `L*` without `Λ`. So, it would be `[a, b, aa, ab, ba, bb, ...]`.
		- If the character set has empty character, it would eventually be yielded. For example, if I have `L = [Λ, a, b]`, `L+ = [Λ, a, b, aa, ab, ...] = L*`.
$$ L^{ +^* } = L^{ *^+ } $$
- **Functions**
	-  Length function
		- Returns length of a string. Count of characters.
		- Reverse function
			- Returns reversed order of the a string.
		- Palindrome  `[Λ plus all strings X, such that Reverse(X) = X]`.
			- `L = [a, b]`. `Palindrome(L) = [Λ, a, b, aa, bb, ...]`.
Introduction to Computer Theory - Daniel I. A Cohen