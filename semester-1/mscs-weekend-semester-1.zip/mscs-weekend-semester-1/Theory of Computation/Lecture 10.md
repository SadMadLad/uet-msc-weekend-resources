**Date: 07 December, 2025**
**Build a Mealy Machine which counts double letters in an Input String**
![[mealy_double_letter_count]]
- **Interconversion between Mealy and Moore Machine**
	- To convert Moore to Mealy Machine, check for incoming edges. Convert all the incoming edges to a specific state with output under the edge. q0/0 --a--> q1/1, will be q0 --a/1--> q1.
	- ![[interconversion_mealy_moore]]
- **Complement of a Language**
	- Convert final state into non-final state. And non-final state into final state.
	- ![[complement_of_language]]
- **De-Movre's**
	- L1 ∩ L2 = (L1' ∪ L2')'