**Date: 30 November, 2025**
- Moore Machine:
	- Collection of 5 things.
		1. Finite number of states q0, q1 ... qn where q0 is a start state.
		2. An alphabet, Σ, of possible input characters for forming input strings. Σ = { a, b, c, ... }
		3. An alphabet τ of possible output characters τ = { x, y, ... }
		4. A transition table that shows each state, output produced and proceed to next by reacting to some input.
		5. An output that shows output produced by states when an input approaches to that state.
	![[moore]]
**Transition Table**

Previous State | Output | a | b
-> q0 | 0 | q1 | q3
q1 | 1 | q2 | q3
q2 | 1 | q3 | q1
q3 | 0 | q2 | q0

**Output Table**

Input: a | b | a | b | b
Output:  0 | 1 | 0 | 1 | 1 | 0
State: q0 | q1 | q3 | q2 | q1 | q3

**Design a Moore machine which counts how many times an input string contains a substring aab**
![[moore_example_1]]
- **Mealy Machine**
	- Collection of 4 things
		1. The first 3 points are the same as Moore Machine.
		2. A pictorial representation that shows each state an input to be read and produces some output.
	- Difference between Mealy and Moore: Moore is State/Output. Mealy is Edge/Output.

**Design a Mealy Machine produces 1's Complement**
![[mealy_example_1]]
**An incremental machine that adds 1 to the bits**
![[incremental]]
**Build a Mealy machine which decrements a given input by 1**
**Build a Mealy machine which produces 'A' when string ends with 01 and 'B' when ends with 11, otherwise produces 'C'.**