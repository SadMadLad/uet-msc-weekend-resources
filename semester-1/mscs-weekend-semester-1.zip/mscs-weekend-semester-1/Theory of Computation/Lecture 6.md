**Date: 26 October, 2025**
- **Kleene's Theorem**
	- A language that can be defined using regular expression, can also be expressed using finite automata, and can also be expressed in transition graph.
	- The theorem has 3 parts
		- A language that can be defined by finite automata can also be defined by transition graph
		- A language that can be defined by transition graph can also be defined with regular expression.
		- A language that can be defined by regular expression can also be defined by finite automata.
		- $RE \subsetneq FA \subsetneq TG \subsetneq RE$
	- **Proof**
		- By definition, every FA is also a TG. (1st Part is proven by definition)
		- Second Part requires constructive proof.
			1. Label states.
			2. Make multiple starting states as single state.
			3. Make multiple final steps into a single final state.
			4. If a TG has same start and final state, separate them.
			5. Get ride of intermediary states by bypassing them and converting them into their respective RE.
![[tg_proof]]