**October 5, 2025**
**Q:** All words don't end with double letter.
**A:** $(a+b)^*(ab+ba)$
**Q:** $b^*(abb^*)^*( Λ+a)$
**A:** All words that don't have double a.
**Q:** $(Λ + a)(ba)^*(Λ+b)$
**A:** All words that don't have double letters.
**Q:** All words having exactly 2 as or 3 as. Not more or less.
**A:** $b^*ab^*ab^* + b^*ab^*ab^*ab^*$
**Q:** $(aa + bb + (ab + ba)(aa + bb)^*(ab + ba))^*$
**A:** All words having even number of as and even number of bs. Also called **even-even** language.
#### **Finite Automata**
Finite number of states, one of which is designated as a start state.
`-` is start state. `+` is end state.
Every state **must** have two transitions, one for 'a' another for 'b'.
![[fa_null_string]]
![[all_words]]